<?php

// String error for length
$error_doctorfirstname_length = '';
$error_doctormiddleinitial_length = '';
$error_doctorlastname_length = '';

//String error for numbers
$error_doctorfirstname_numeric = '';
$error_doctormiddleinitial_numeric = '';
$error_doctorlastname_numeric = '';

//String error for special characters
$error_doctorfirstname_specialcharac = '';
$error_doctormiddleinitial_specialcharac = '';
$error_doctorlastname_specialcharac = '';

//String error in password
$error_doctorpassword = '';
$error_nodoctorpass = '';

?>