<?php
$conn = mysqli_connect('localhost', 'root', '', 'welltechcare') or die("Could not connect to WellTech Care Database".mysqli_error($conn));
?>