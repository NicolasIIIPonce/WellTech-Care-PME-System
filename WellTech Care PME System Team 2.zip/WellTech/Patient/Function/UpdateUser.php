<script>
function UpdateClick()
{
    document.getElementById('editFN').removeAttribute('readonly');
    document.getElementById('editMN').removeAttribute('readonly');
    document.getElementById('editLN').removeAttribute('readonly');
    document.getElementById('editHeight').removeAttribute('readonly');
    document.getElementById('editWeight').removeAttribute('readonly');
    document.getElementById('editAddress').removeAttribute('readonly');
    document.getElementById('editContactNo').removeAttribute('readonly');
    document.getElementById('editUsername').removeAttribute('readonly');
}
</script>
<?php
include ('Function/db.php');


?>
