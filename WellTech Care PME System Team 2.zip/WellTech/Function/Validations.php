<?php

//String error for Length Validations
$error_FirstName_Length = '';
$error_MiddleName_Length = '';
$error_LastName_Length = '';

//String error if the ff contains numbers
$error_FirstName_Numeric = '';
$error_MiddleName_Numeric ='';
$error_LastName_Numeric = '';

//String error if the ff contains special charac
$error_FirstName_Speccharac = '';
$error_MiddleName_Speccharac = '';
$error_LastName_Speccharac = '';


//String error in username length
$error_Username_Length = '';
//String error in username
$error_Username = '';

//String error in password
$error_Password = '';
$error_NoPass = '';
$error_NoConfirmationPass = '';
//String error in password must contain num and special charac
//$error_Password_Numeric = '';
//$error_Password_Speccharac = '';

//String error in otp
$error_VCode = '';

?>