<?php
$conn=  mysqli_connect('localhost','root','','welltech')or die("Could not connect to mysql".mysqli_error($conn));

?>